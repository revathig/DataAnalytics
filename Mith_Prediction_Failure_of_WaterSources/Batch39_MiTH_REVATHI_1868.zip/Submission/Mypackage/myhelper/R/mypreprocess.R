
###loading the required libraries

library(caret)
library(DataExplorer)
library(DMwR)
library(dplyr)
library(C50)
library(rpart)
library(randomForest)
library(ROCR)
library(corrplot)
library(e1071)
library(class)
library(ada)
library(xgboost)
library(forcats)



#################################3
#clearenv <- function(){
 # rm(list = ls(all = TRUE))
#}
#####################################3


#####################################################
##Open the file and do the basic initial viewing
#####################################################

readdata <- function(path,file)
{
  setwd(path)
  Data = read.csv(file)
  return(Data)
}

### get the rownumber of the outlier in the particular attribute
##Not removing here. Leaving the emoval decison to the calling function
removeoutlier = function(columndata, nrows)
{
  max_col_val = max(columndata, na.rm=T)

  i =1
  while(i <  nrows)
  {
    curval = columndata[i]
    curval
    if (max_col_val == curval ) {
      rownum = i
      break

    }
    i= i+1

  }

  return(rownum)
}

####Print the columns which possibly have outliers
###As of now it is not very nice but useful to predict.

FindOutliers <- function(numeric_attrdata)
{
  i =1
  while(i < ncol(numeric_attrdata))
  {
    summarycol = summary(numeric_attrdata[ , i])

    if((summarycol["3rd Qu."]*2) < summarycol["Max."])
    {
      print(colnames(numattr[i]))
      print(summarycol)
    }
    i= i+1
  }

}

###Get the character attribute
###Later we might need to change them to categorical

getcharattr <-function(data)
{
  charattr = data[ ,sapply(data,is.character)]
  return(charattr)
}

####Get the categorical subset from the data
getcatgoricalattr <- function(data)
{
  categoricalattr = data[ ,sapply(data, is.factor)]
  return (categoricalattr)
}

####Get the numerical subset from the data
getnumericalattr <- function(data)
{
  numericattr = data[ ,sapply(data, is.numeric)]
  return (numericattr)
}


#####Reduce the number levels in categorical attribute
###usingforcats library fct_collapse function

catatt_reducelevels <- function(attr, newlevel, levels)
{
  print(newlevel)

  attr = fct_collapse(attr, newlevel = levels)
  levels(attr)[levels(attr)=="newlevel"] <- newlevel

  return(attr)
}


#### Visuvalization of data
### Plot missing is the best
###Not sure i will call this I will call the individual functions below
DataVisualize <-function(data)
{
  plot_str(data)
  plot_missing(data)
  plot_histogram(data)
  plot_density(data)
  plot_correlation(data)
}

### Prediction function
###

model_predict <- function(model, data_to_predict, type="response", isRF = FALSE, threshhold = 0)
{
   if(isRF)
   {
     pred_val = predict(model, data_to_predict, type=type, norm.votes=TRUE)
   }else
   {
     pred_val = predict(model, data_to_predict, type= type)
   }

   if(threshhold >0)
   {
     pred_val = ifelse(pred_val>threshhold,"functional","non functional")
   }

   pred_val
}

##change to return the required method
#accuracy or f1

model_analysis <- function(model, data_to_predict, y_val, type="response", isRF = FALSE, threshhold = 0, positive="1")
{
  pred_val = model_predict(model,data_to_predict, type, isRF, threshhold)

  cm = confusionMatrix(pred_val, y_val, positive)
  print(cm)
}

# write ti a file
## need to change here

Createoutputfile <- function(model, data_to_predict, type="response",
                             isRF = FALSE, threshhold = 0, positive="1")
{
  pred_val = model_predict(model,data_to_predict, type, isRF, threshhold)
  write.csv(pred_val,file="TestPred.csv")

  myoutput = read.csv("TestPred.csv", header =T)
  str(myoutput)


  colnames(myoutput) = c("index", "target")

  colnames(myoutput)
  str(myoutput)

  write.csv(file = "myfinaloutput1.csv",x= myoutput,row.names = FALSE)

}

